# 套件状态快照（2026-11-22）

## 已验证可用

| 能力 | 状态 | 说明 |
|---|---|---|
| 实时链路 | ✅ | RT 内核 6.8.2-rt11-rt，隔离核 14-15，cyclictest max 67 us |
| 位置控制移动 | ✅ | safe_goto / safe_goto_retry，终点误差 0.1~1 mm |
| 姿态示教/回放 | ✅ | safe_record / safe_goto / safe_sequence |
| 夹爪控制 | ✅ | 宽度判据（is_grasped 不可靠，已绕开） |
| ESN 推理 | ✅ | 与官方离线实现逐帧一致（误差 5e-5） |
| 减速通道 (a0) | ✅ | 推力越大速度越低（100% → 20%） |
| 接触门控 | ✅ | 12 N 进入 / 9 N 退出 + 0.3 s 确认；无接触时完全旁路 |
| 让位通道 | ⚠️ | 有位移贡献，但方向与外力相关性仅 +0.33（teacher 为 +0.95） |

## 关键参数（esn_yield）

- 关节刚度 300 Nm/rad；碰撞阈值 contact 20Nm/15N、collision 1000Nm/1000N
- 减速: 速度倍率 = 1 - 0.8*a0，a0 低通 0.2 s
- 让位: 量程 0.18 m / 0.35 rad，速率 0.15 rad/s，加速度 1.0 rad/s²，关节偏移 ≤0.25 rad
- 让位符号: 取反（dq = -(J^T (JJ^T+λ²I)^-1 y)，λ=0.05）
- 门控: |F|>12 N 进，<9 N 持续 0.3 s 出
- 观测: 外力中位数校准 + 按末端姿态旋转补偿 + 死区 1.5 N / 0.15 Nm

## 已知问题（未解决）

1. **让位方向不对齐**：同一批观测下 VMC(teacher) 让位方向与力余弦 +0.948，ESN 仅 +0.330。
   推测是训练时的观测定义（14-31 通道）与我们的组装不一致。需要 `fci_shadow.cpp` 或训练侧 observation 代码。
2. **力矩通道可疑**：模型 k_scale={8,8,8,1,1,1}，力矩截断仅 ±12 Nm，而我们实测 Mx/My/Mz 峰值 8~11.5 Nm，
   接近截断。需要核实力矩的参考点/坐标系与训练是否一致。
3. **Franka Hand 遥测异常**：max_width 恒 0.0523、temperature 坏值、is_grasped 不可靠。
4. **网卡为 Realtek RTL8111**：偶发延迟尖峰（max 3.9 ms），建议换 Intel I210。

## 复现/编译

    cd franka-safe && cmake -S . -B build && cmake --build build -j$(nproc)

依赖: libfranka 0.21.3 + pinocchio 3.4.0（装在 /usr/local），见 docs/。
