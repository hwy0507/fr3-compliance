cmake_minimum_required(VERSION 3.10)
project(franka_safe CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

find_package(Franka REQUIRED)

foreach(prog safe_nudge safe_wrist safe_record safe_goto safe_sequence safe_cycle safe_gripper safe_fk gripper_force_probe safe_compliant safe_move_nostop safe_soft_move safe_goto_retry)
  add_executable(${prog} ${prog}.cpp)
  target_link_libraries(${prog} PRIVATE franka)
endforeach()

# ESN 影子模式（需要 Eigen + 交接包路径）
find_package(Eigen3 REQUIRED)
add_executable(esn_shadow esn_shadow.cpp)
target_include_directories(esn_shadow PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../FR3_ESN128_main /usr/include/eigen3)
target_link_libraries(esn_shadow PRIVATE franka)

add_executable(esn_slowdown esn_slowdown.cpp)
target_include_directories(esn_slowdown PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../FR3_ESN128_main /usr/include/eigen3)
target_link_libraries(esn_slowdown PRIVATE franka)

add_executable(esn_yield esn_yield.cpp)
target_include_directories(esn_yield PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../FR3_ESN128_main /usr/include/eigen3)
target_link_libraries(esn_yield PRIVATE franka)

add_executable(esn_vs_vmc esn_vs_vmc.cpp)
target_include_directories(esn_vs_vmc PRIVATE ${CMAKE_CURRENT_SOURCE_DIR}/../FR3_ESN128_main /usr/include/eigen3)
