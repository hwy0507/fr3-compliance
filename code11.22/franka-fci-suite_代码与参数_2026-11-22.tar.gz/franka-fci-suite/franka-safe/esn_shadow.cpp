// esn_shadow.cpp — ESN 影子模式：机械臂正常运动，策略只"旁听"不干预
//
// 用法:
//   ./esn_shadow <IP> <起点姿态> <终点姿态> [峰值速度rad/s]
// 例:
//   ./esn_shadow 172.16.0.2 home pos2 0.12
//
// 行为:
//   1. 关节空间余弦轨迹从"起点姿态"走到"终点姿态"（位置控制，正常下发）
//   2. 每 40 ms 组装一次 canonical48 观测，调用 Esn128 策略
//   3. 打印策略输出（减速量 + 6 个让位通道）与实测外力
//   4. **不把策略动作施加到机械臂**（影子模式，零风险）
//
// 观测组装（canonical48，下标从 0 开始）:
//    0-6   q                 7-13  dq
//   14-16  名义末端线速度     17-19 名义角速度
//   20-22  位置误差(名义-实测) 23-25 旋转误差
//   26-28  名义-实测线速度    29-31 名义-实测角速度
//   32-38  tau_ext_hat_filtered
//   39-44  O_F_ext_hat_K
//   45-47  路径方向单位向量 (XY)
//
// ⚠️ 坐标系/符号/TCP 需与训练一致，本程序按如下约定实现，需在影子模式里核对:
//   - 位姿来自 Frame::kEndEffector（含 F_T_EE 的 0.255 m 偏移）
//   - 位置误差 = 名义 - 实测；速度误差 = 名义 - 实测
//   - 路径方向 = 名义末端位置在 XY 平面上的运动方向

#include <array>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

#include <Eigen/Core>
#include <Eigen/Geometry>

#include <franka/exception.h>
#include <franka/model.h>
#include <franka/robot.h>

#include "../FR3_ESN128_main/fr3_esn128/esn_actor.hpp"

namespace {

constexpr double kPolicyDt = 0.04;   // 25 Hz
constexpr double kHoldSeconds = 1.0;

std::string posePath(const std::string& name) {
  const char* h = std::getenv("HOME");
  return std::string(h ? h : ".") + "/franka-poses/" + name + ".json";
}

bool parseQ(const std::string& text, std::array<double, 7>* q) {
  size_t pos = text.find("\"q\"");
  if (pos == std::string::npos) return false;
  pos = text.find('[', pos);
  if (pos == std::string::npos) return false;
  size_t end = text.find(']', pos);
  if (end == std::string::npos) return false;
  std::string body = text.substr(pos + 1, end - pos - 1);
  for (char& c : body) {
    if (c == ',') c = ' ';
  }
  std::istringstream iss(body);
  for (size_t i = 0; i < 7; ++i) {
    if (!(iss >> (*q)[i])) return false;
  }
  return true;
}

bool loadQ(const std::string& name, std::array<double, 7>* q) {
  std::ifstream in(posePath(name));
  if (!in) return false;
  std::stringstream buf;
  buf << in.rdbuf();
  return parseQ(buf.str(), q);
}

// 4x4 列主序 -> 位置与旋转
struct Pose {
  Eigen::Vector3d p;
  Eigen::Matrix3d R;
};

Pose toPose(const std::array<double, 16>& T) {
  Pose out;
  out.p << T[12], T[13], T[14];
  for (int c = 0; c < 3; ++c) {
    for (int r = 0; r < 3; ++r) {
      out.R(r, c) = T[c * 4 + r];
    }
  }
  return out;
}

// 旋转矩阵差 -> 角速度向量 (rad/s)
Eigen::Vector3d angularVelocity(const Eigen::Matrix3d& R_prev,
                                const Eigen::Matrix3d& R_now, double dt) {
  Eigen::Matrix3d dR = R_now * R_prev.transpose();
  Eigen::AngleAxisd aa(dR);
  return aa.axis() * aa.angle() / dt;
}

// 旋转误差 (名义 vs 实测) -> 轴角向量
Eigen::Vector3d rotationError(const Eigen::Matrix3d& R_nom,
                              const Eigen::Matrix3d& R_act) {
  Eigen::Matrix3d dR = R_nom * R_act.transpose();
  Eigen::AngleAxisd aa(dR);
  return aa.axis() * aa.angle();
}

void setCollisionHigh(franka::Robot& r) {
  // 抗干扰：collision 放开，推撞不触发 reflex（仅影子测试用）
  r.setCollisionBehavior({{20, 20, 18, 18, 15, 12, 10}},
                         {{1000, 1000, 1000, 1000, 1000, 1000, 1000}},
                         {{20, 20, 18, 18, 15, 12, 10}},
                         {{1000, 1000, 1000, 1000, 1000, 1000, 1000}},
                         {{15, 15, 15, 20, 20, 20}},
                         {{1000, 1000, 1000, 1000, 1000, 1000}},
                         {{15, 15, 15, 20, 20, 20}},
                         {{1000, 1000, 1000, 1000, 1000, 1000}});
}

void setCollisionNormal(franka::Robot& r) {
  r.setCollisionBehavior({{15, 15, 12, 12, 10, 8, 6}},
                         {{40, 40, 36, 36, 32, 28, 24}},
                         {{15, 15, 12, 12, 10, 8, 6}},
                         {{40, 40, 36, 36, 32, 28, 24}},
                         {{10, 10, 10, 15, 15, 15}},
                         {{40, 40, 40, 60, 60, 60}},
                         {{10, 10, 10, 15, 15, 15}},
                         {{40, 40, 40, 60, 60, 60}});
}

}  // namespace

int main(int argc, char** argv) {
  if (argc < 4) {
    std::cout << "用法: " << argv[0]
              << " <IP> <起点姿态> <终点姿态> [峰值速度rad/s]\n"
              << "例:   " << argv[0] << " 172.16.0.2 home pos2 0.12\n"
              << "      " << argv[0] << " 172.16.0.2 home pos2 0.12 high  (可推撞)\n";
    return 1;
  }
  const std::string ip = argv[1];
  const std::string from_name = argv[2];
  const std::string to_name = argv[3];
  double speed = (argc > 4) ? std::atof(argv[4]) : 0.12;
  if (speed <= 0.0 || speed > 1.0) speed = 0.12;
  bool allow_push = (argc > 5) && (std::string(argv[5]) == "high");

  std::array<double, 7> q_from{}, q_to{};
  if (!loadQ(from_name, &q_from)) {
    std::cerr << "找不到姿态: " << posePath(from_name) << "\n";
    return 1;
  }
  if (!loadQ(to_name, &q_to)) {
    std::cerr << "找不到姿态: " << posePath(to_name) << "\n";
    return 1;
  }

  try {
    franka::Robot robot(ip);
    franka::Model model = robot.loadModel();
    if (allow_push) {
      setCollisionHigh(robot);
      std::cout << "已连接 " << ip << "  （影子模式 + 抗干扰阈值：可以推）\n";
    } else {
      setCollisionNormal(robot);
      std::cout << "已连接 " << ip << "  （影子模式：策略动作不会下发）\n";
    }

    // 先走到起点
    {
      franka::RobotState st = robot.readOnce();
      double md = 0.0;
      for (size_t i = 0; i < 7; ++i) md = std::max(md, std::abs(q_from[i] - st.q[i]));
      if (md > 0.02) {
        std::cout << "先移动到起点 " << from_name << "（最大差 " << md
                  << " rad）...\n";
        bool init = false;
        std::array<double, 7> qs{}, qc{};
        double T = M_PI * md / (2.0 * 0.15), t = 0.0, hold = 0.0;
        robot.control(
            [&](const franka::RobotState& rs,
                franka::Duration period) -> franka::JointPositions {
              if (!init) {
                qs = rs.q;
                qc = qs;
                init = true;
                return franka::JointPositions(qc);
              }
              const double dt = period.toSec();
              t += dt;
              const double s =
                  (t >= T) ? 1.0 : (1.0 - std::cos(M_PI * t / T)) / 2.0;
              for (size_t i = 0; i < 7; ++i) {
                qc[i] = qs[i] + (q_from[i] - qs[i]) * s;
              }
              if (t >= T && (hold += dt) >= kHoldSeconds) {
                return franka::MotionFinished(franka::JointPositions(qc));
              }
              return franka::JointPositions(qc);
            },
            franka::ControllerMode::kJointImpedance, true, 100.0);
      }
    }

    // ---- 外力零偏校准：静止读 200 帧（约 200ms），取均值 ----
    Eigen::Matrix<double, 6, 1> f_bias = Eigen::Matrix<double, 6, 1>::Zero();
    Eigen::Matrix3d R_cal = Eigen::Matrix3d::Identity();
    {
      int n = 0;
      franka::RobotState st_cal{};
      robot.read([&](const franka::RobotState& rs) {
        for (size_t i = 0; i < 6; ++i) f_bias[i] += rs.O_F_ext_hat_K[i];
        st_cal = rs;
        return ++n < 200;
      });
      f_bias /= static_cast<double>(n);
      R_cal = toPose(model.pose(franka::Frame::kEndEffector, st_cal)).R;
      std::printf("外力零偏校准(基线): [%.2f %.2f %.2f | %.2f %.2f %.2f] N/Nm\n",
                  f_bias[0], f_bias[1], f_bias[2], f_bias[3], f_bias[4],
                  f_bias[5]);
    }
    // 把基线偏置换算到末端坐标系 -> 之后按当前姿态旋转回来,
    // 近似补偿"未建模负载随姿态变化的重力投影"
    const Eigen::Vector3d c_force = R_cal.transpose() * f_bias.head<3>();
    const Eigen::Vector3d c_moment = R_cal.transpose() * f_bias.tail<3>();
    std::printf("末端系固定偏置: F=[%.2f %.2f %.2f] N  M=[%.2f %.2f %.2f] Nm\n",
                c_force[0], c_force[1], c_force[2], c_moment[0], c_moment[1],
                c_moment[2]);

    // ---- CSV 日志 ----
    FILE* csv = std::fopen("/tmp/esn_shadow_obs.csv", "w");
    if (csv) {
      std::fprintf(csv, "t");
      for (int i = 0; i < 48; ++i) std::fprintf(csv, ",obs%d", i);
      for (int i = 0; i < 7; ++i) std::fprintf(csv, ",a%d", i);
      std::fprintf(csv, "\n");
      std::fflush(csv);
    }

    // ---- 主循环：走 nomin 轨迹 + 影子推理 ----
    fr3_esn128::Esn128 policy;
    fr3_esn128::ActionFilter filter;
    policy.reset();

    bool initialized = false;
    std::array<double, 7> q_start{};
    std::array<double, 7> q_ref{};
    double T = 0.0, t = 0.0, hold = 0.0, next_tick = 0.0;
    bool have_prev = false;
    Pose prev_nom{}, prev_act{};

    // 固定任务方向: 起点 -> 终点的 XY 单位向量 (与训练一致的做法)
    Eigen::Vector3d path_dir = Eigen::Vector3d::Zero();
    {
      franka::RobotState st_tmp = robot.readOnce();
      for (size_t i = 0; i < 7; ++i) st_tmp.q[i] = q_from[i];
      const Eigen::Vector3d p_from =
          toPose(model.pose(franka::Frame::kEndEffector, st_tmp)).p;
      for (size_t i = 0; i < 7; ++i) st_tmp.q[i] = q_to[i];
      const Eigen::Vector3d p_to =
          toPose(model.pose(franka::Frame::kEndEffector, st_tmp)).p;
      Eigen::Vector3d d = p_to - p_from;
      d.z() = 0.0;
      if (d.norm() > 1e-6) path_dir = d.normalized();
      std::printf("任务方向(XY): [%.3f %.3f %.3f]  (起点->终点)\n", path_dir[0],
                  path_dir[1], path_dir[2]);
    }

    double max_force = 0.0, max_a0 = 0.0;
    int ticks = 0;

    std::cout << "\n开始：发出动作不会影响机械臂（影子）。\n";
    std::printf(" %6s | %7s | %8s | %7s | %7s\n", "t(s)", "a0", "yield_xyz",
                "|F|N", "disp(mm)");
    std::printf("--------+---------+----------+---------+---------\n");

    robot.control(
        [&](const franka::RobotState& rs,
            franka::Duration period) -> franka::JointPositions {
          if (!initialized) {
            q_start = rs.q;
            q_ref = q_start;
            double md = 0.0;
            for (size_t i = 0; i < 7; ++i) {
              md = std::max(md, std::abs(q_to[i] - q_start[i]));
            }
            T = (md > 0) ? M_PI * md / (2.0 * speed) : 0.0;
            initialized = true;
            return franka::JointPositions(q_ref);
          }

          const double dt = period.toSec();
          t += dt;

          // 名义关节轨迹（余弦）
          const double s = (T <= 0.0 || t >= T)
                               ? 1.0
                               : (1.0 - std::cos(M_PI * t / T)) / 2.0;
          for (size_t i = 0; i < 7; ++i) {
            q_ref[i] = q_start[i] + (q_to[i] - q_start[i]) * s;
          }

          // ---- 每 40ms 做一次策略推理 ----
          if (t >= next_tick) {
            next_tick += kPolicyDt;

            franka::RobotState st_nom = rs;
            for (size_t i = 0; i < 7; ++i) st_nom.q[i] = q_ref[i];
            const Pose nom = toPose(model.pose(franka::Frame::kEndEffector, st_nom));
            const Pose act = toPose(model.pose(franka::Frame::kEndEffector, rs));

            fr3_esn128::Obs obs;
            obs.setZero();
            for (size_t i = 0; i < 7; ++i) {
              obs[i] = rs.q[i];
              obs[7 + i] = rs.dq[i];
              obs[32 + i] = rs.tau_ext_hat_filtered[i];
            }
            // 姿态相关的偏置补偿: 把校准时的末端系偏置按当前姿态旋转
            const Eigen::Vector3d bias_f = act.R * c_force;
            const Eigen::Vector3d bias_m = act.R * c_moment;
            for (size_t i = 0; i < 3; ++i) {
              obs[39 + i] = rs.O_F_ext_hat_K[i] - bias_f[i];
              obs[42 + i] = rs.O_F_ext_hat_K[3 + i] - bias_m[i];
            }

            Eigen::Vector3d v_nom = Eigen::Vector3d::Zero(), w_nom = Eigen::Vector3d::Zero();
            Eigen::Vector3d v_act = Eigen::Vector3d::Zero(), w_act = Eigen::Vector3d::Zero();
            if (have_prev) {
              v_nom = (nom.p - prev_nom.p) / kPolicyDt;
              w_nom = angularVelocity(prev_nom.R, nom.R, kPolicyDt);
              v_act = (act.p - prev_act.p) / kPolicyDt;
              w_act = angularVelocity(prev_act.R, act.R, kPolicyDt);
            }
            prev_nom = nom;
            prev_act = act;
            have_prev = true;

            for (size_t i = 0; i < 3; ++i) {
              obs[14 + i] = v_nom[i];           // 名义线速度
              obs[17 + i] = w_nom[i];           // 名义角速度
              obs[20 + i] = nom.p[i] - act.p[i];// 位置误差
              obs[26 + i] = v_nom[i] - v_act[i];// 线速度误差
              obs[29 + i] = w_nom[i] - w_act[i];// 角速度误差
            }
            const Eigen::Vector3d rerr = rotationError(nom.R, act.R);
            for (size_t i = 0; i < 3; ++i) obs[23 + i] = rerr[i];

            for (size_t i = 0; i < 3; ++i) obs[45 + i] = path_dir[i];

            const fr3_esn128::V7 action = policy.step(obs, kPolicyDt);
            filter.update(action);

            const Eigen::Vector3d f_cal =
                Eigen::Vector3d(obs[39], obs[40], obs[41]);
            const double f_ext = f_cal.norm();
            if (csv) {
              std::fprintf(csv, "%.4f", t);
              for (int i = 0; i < 48; ++i) std::fprintf(csv, ",%.6f", obs[i]);
              for (int i = 0; i < 7; ++i) std::fprintf(csv, ",%.6f", action[i]);
              std::fprintf(csv, "\n");
            }
            max_force = std::max(max_force, f_ext);
            max_a0 = std::max(max_a0, action[0]);
            ++ticks;

            if ((ticks % 5) == 0) {  // 每 200ms 打印一行，避免刷屏
              std::printf(" %6.2f | %7.3f | %8.3f | %7.2f | %7.1f\n", t, action[0],
                          filter.yield[0],
                          f_ext,
                          (act.p - nom.p).norm() * 1000.0);
            }
          }

          if (t >= T) {
            hold += dt;
            if (hold >= kHoldSeconds) {
              return franka::MotionFinished(franka::JointPositions(q_ref));
            }
          }
          return franka::JointPositions(q_ref);
        },
        franka::ControllerMode::kJointImpedance, true, 100.0);

    if (csv) {
      std::fclose(csv);
      std::cout << "观测/动作日志: /tmp/esn_shadow_obs.csv\n";
    }
    std::printf("\n影子运行结束: %d 次策略调用, max|F| = %.2f N, max a0 = %.3f\n",
                ticks, max_force, max_a0);
    std::cout << "注意: 以上策略动作全部未下发。\n";
  } catch (const franka::Exception& e) {
    std::cerr << "\n[异常] " << e.what() << "\n";
    return 1;
  }
  return 0;
}
