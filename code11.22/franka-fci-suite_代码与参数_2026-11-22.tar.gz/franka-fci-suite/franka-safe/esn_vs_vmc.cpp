// esn_vs_vmc.cpp — 用同一批 obs48 对比 ESN 与 VMC(teacher) 的输出
//
// 用法: ./esn_vs_vmc /tmp/esn_shadow_obs.csv
// 作用: 逐帧同时跑 ActiveVmc 与 Esn128, 统计
//       ① 两者动作的相关性
//       ② 各自让位方向与外力方向的夹角余弦
//       ③ VMC 内部 offset 与力的关系
// 不连接机器人, 纯离线分析。

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "../FR3_ESN128_main/fr3_esn128/esn_actor.hpp"

int main(int argc, char** argv) {
  if (argc < 2) {
    std::cout << "用法: " << argv[0] << " <obs_csv>\n";
    return 1;
  }
  std::ifstream in(argv[1]);
  if (!in) {
    std::cerr << "打不开 " << argv[1] << "\n";
    return 1;
  }
  std::string line;
  std::getline(in, line);  // 表头

  const int g_variant = (argc > 2) ? std::atoi(argv[2]) : 0;
  fr3_contact::ActiveVmc vmc;
  fr3_esn128::Esn128 esn;
  esn.reset();

  size_t n = 0, contact = 0;
  double cos_esn = 0.0, cos_vmc = 0.0, dot_esn_vmc = 0.0;
  double n_esn_align = 0.0, n_vmc_align = 0.0, norm_esn = 0.0, norm_vmc = 0.0;

  while (std::getline(in, line)) {
    if (line.empty()) continue;
    std::vector<double> vals;
    std::stringstream ss(line);
    std::string tok;
    while (std::getline(ss, tok, ',')) vals.push_back(std::atof(tok.c_str()));
    if (vals.size() < 1 + 48 + 7) continue;

    fr3_contact::Obs obs;
    for (int i = 0; i < 48; ++i) obs[i] = vals[1 + i];

    const fr3_contact::V7 a_vmc = vmc.step(obs, 0.04);
    // 变体: 用不同假设的 obs 喂 ESN, 看哪种对齐最好
    fr3_contact::Obs o2 = obs;
    if (g_variant == 1) {                 // 清空上下文
      for (int i = 14; i < 20; ++i) o2[i] = 0;
      for (int i = 26; i < 32; ++i) o2[i] = 0;
      for (int i = 45; i < 48; ++i) o2[i] = 0;
    } else if (g_variant == 2) {          // 位置误差反号
      for (int i = 20; i < 26; ++i) o2[i] = -o2[i];
    } else if (g_variant == 3) {          // 速度误差反号
      for (int i = 26; i < 32; ++i) o2[i] = -o2[i];
    } else if (g_variant == 4) {          // 名义速度反号
      for (int i = 14; i < 20; ++i) o2[i] = -o2[i];
    } else if (g_variant == 5) {          // 速度减半
      for (int i = 14; i < 20; ++i) o2[i] *= 0.5;
      for (int i = 26; i < 32; ++i) o2[i] *= 0.5;
    } else if (g_variant == 6) {          // 路径方向反号
      for (int i = 45; i < 48; ++i) o2[i] = -o2[i];
    }
    const fr3_contact::V7 a_esn = esn.step(o2, 0.04);

    // 力的水平分量
    const double fx = obs[39], fy = obs[40];
    const double f_norm = std::sqrt(fx * fx + fy * fy);
    ++n;

    if (f_norm > 5.0) {
      ++contact;
      // 让位方向的 XY 分量
      const double ex = a_esn[1], ey = a_esn[2];
      const double vx = a_vmc[1], vy = a_vmc[2];
      const double en = std::sqrt(ex * ex + ey * ey);
      const double vn = std::sqrt(vx * vx + vy * vy);
      if (en > 1e-6) {
        const double c = (fx * ex + fy * ey) / (f_norm * en);
        cos_esn += c;
        n_esn_align += (c > 0.5 ? 1 : 0);
        norm_esn += en;
      }
      if (vn > 1e-6) {
        const double c = (fx * vx + fy * vy) / (f_norm * vn);
        cos_vmc += c;
        n_vmc_align += (c > 0.5 ? 1 : 0);
        norm_vmc += vn;
      }
      if (en > 1e-6 && vn > 1e-6) {
        dot_esn_vmc += (ex * vx + ey * vy) / (en * vn);
      }
    }
  }

  std::printf("总帧数 %zu, 有接触(|F|>5N) %zu 帧\n", n, contact);
  if (contact == 0) {
    std::cout << "没有接触帧, 无法比较\n";
    return 0;
  }
  const double c = static_cast<double>(contact);
  std::printf("ESN 让位方向 vs 力 余弦均值: %+.3f  (顺力占比 %.0f%%)\n",
              cos_esn / c, n_esn_align / c * 100.0);
  std::printf("VMC 让位方向 vs 力 余弦均值: %+.3f  (顺力占比 %.0f%%)\n",
              cos_vmc / c, n_vmc_align / c * 100.0);
  std::printf("ESN 与 VMC 让位方向一致性: %+.3f\n", dot_esn_vmc / c);
  std::printf("让位幅度均值: ESN %.3f, VMC %.3f\n", norm_esn / c, norm_vmc / c);
  return 0;
}
