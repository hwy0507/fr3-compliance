# FR3 + ESN 控制套件（打包快照 2026-11-21）

这是把本机所有相关程序、模型、脚本、文档集中到一处的**备份副本**。
原始目录（`~/franka-safe`、`~/FR3_ESN128_main`、`~/rt-setup`、`~/franka-poses`）**仍然保留、未被移动**。

---

## 目录结构

```
franka-fci-suite/
├── franka-safe/                自研工具（13 个 C++ 程序 + build/）
│   ├── esn_yield.cpp           ★ 主程序：ESN 减速+让位控制
│   ├── esn_slowdown.cpp        只用减速通道
│   ├── esn_shadow.cpp          只观察不动作
│   ├── esn_vs_vmc.cpp          离线对比 ESN 与 VMC 的让位方向
│   ├── safe_goto_retry.cpp     带自动恢复的位置控制移动
│   ├── safe_goto.cpp / safe_sequence.cpp / safe_cycle.cpp ...
│   ├── safe_gripper.cpp / gripper_force_probe.cpp ...
│   ├── esn_yield_params.md     ★ 当前认可版本的参数说明
│   └── esn_yield_good_2026-11-21.cpp.bak   源码备份
│
├── FR3_ESN128_main/            ESN 模型包（勿改相对路径）
│   ├── fr3_esn128/esn_actor.hpp        策略本体
│   ├── fr3_esn128/model_generated.inc  冻结权重（617 KB）
│   ├── fr3_contact/active_vmc.hpp      VMC teacher（仅参考）
│   └── main.cpp / example_obs48.txt    官方离线推理示例
│
├── franka-poses/               姿态快照（home.json / pos2.json）
├── rt-setup/                   实时内核、网卡调优、验收脚本
├── docs/                       操作手册 PDF + 复现包 + 参数说明
└── std-logs/                   最近几次运行的日志
```

---

## 运行方式（和原来完全一样）

```bash
# 主程序：ESN 减速 + 让位
chrt -f 80 taskset -c 14 ~/franka-fci-suite/franka-safe/build/esn_yield \
    172.16.0.2 home pos2 0.15 high

# 纯位置控制移动（带自动恢复）
chrt -f 80 taskset -c 14 ~/franka-fci-suite/franka-safe/build/safe_goto_retry \
    172.16.0.2 home 0.15 5 0.02
```

重新编译：

```bash
cd ~/franka-fci-suite/franka-safe
cmake -S . -B build && cmake --build build -j$(nproc)
```

---

## 注意事项（重要）

| 项 | 说明 |
|---|---|
| **姿态文件路径** | 程序仍从 `~/franka-poses/` 读取，**不是**从本文件夹。<br>要改姿态请改 `~/franka-poses/`，或把本文件夹的 `franka-poses/` 拷回去。 |
| **运行日志** | 写到 `/tmp/esn_shadow_obs.csv`（每次运行覆盖）。`std-logs/` 里是文本输出的快照。 |
| **依赖库** | libfranka 0.21.3 和 pinocchio 3.4.0 装在 `/usr/local`，不在本文件夹内。换机器需按 `docs/franka-fci-repro.tar.gz` 重建。 |
| **相对路径** | `franka-safe/*.cpp` 里用 `#include "../FR3_ESN128_main/..."`，所以两个目录必须保持同级。 |
| **实时环境** | RT 内核、CPU 隔离、网卡 IP 都在系统层，不在本文件夹。相关脚本在 `rt-setup/`。 |

---

## 这套东西能做什么

- `esn_yield`：从 home 平滑走到 pos2；无接触时与纯轨迹完全一致（丝滑）；
  被推（>12 N）时 ESN 输出减速 + 让位；松手（<9 N 持续 0.3 s）自动恢复；最终仍精确到达目标。
- 实测：推力 28 N → 速度降到 25%、让位 184 mm，全程无急停，终点误差 7 mm。

详见 `franka-safe/esn_yield_params.md`。
