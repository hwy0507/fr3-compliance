// Each line is one canonical48 policy observation, spaced 40 ms apart in the task.
#include "fr3_esn128/esn_actor.hpp"
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>

int main(int argc, char** argv) {
  if (argc > 2) {
    std::cerr << "Usage: esn_main [observations.txt]\n";
    return 2;
  }
  std::ifstream file;
  if (argc == 2) {
    file.open(argv[1]);
    if (!file) {
      std::cerr << "Cannot open " << argv[1] << '\n';
      return 1;
    }
  }
  std::istream& input = argc == 2 ? static_cast<std::istream&>(file) : std::cin;
  fr3_esn128::Esn128 policy;  // One instance per episode. It remembers previous observations.
  std::cout << std::setprecision(17);
  std::string line;
  size_t line_number = 0, frames = 0;
  try {
    while (std::getline(input, line)) {
      ++line_number;
      std::istringstream row(line);
      row >> std::ws;
      if (row.eof()) continue;
      fr3_esn128::Obs observation;
      for (double& value : observation) {
        if (!(row >> value) || !std::isfinite(value))
          throw std::runtime_error("expected 48 finite numbers");
      }
      if (!(row >> std::ws).eof()) throw std::runtime_error("unexpected data after column 48");

      const auto action = policy.step(observation);
      std::cout << action.transpose() << '\n';  // 1 slowdown activation + 6 normalized yield channels
      ++frames;
    }
    if (input.bad()) throw std::runtime_error("input read failed");
    if (frames == 0) throw std::runtime_error("no observation frames supplied");
  } catch (const std::exception& e) {
    std::cerr << "Input line " << line_number << ": " << e.what() << '\n';
    return 1;
  }
  return 0;
}
