#!/usr/bin/env bash
# ============================================================
# 回滚: 撤销 limits 与 GRUB 隔离参数
# 用法: sudo bash /tmp/rt-setup/rollback.sh [用户名]
# 说明: 不会删除已安装的 RT 内核; 想删内核用
#       sudo apt remove linux-image-*-rt linux-headers-*-rt
# ============================================================
set -euo pipefail

TARGET_USER="${1:-${SUDO_USER:-}}"
GRUB_FILE=/etc/default/grub
LIMITS_DST=/etc/security/limits.d/99-realtime.conf

if [[ $EUID -ne 0 ]]; then echo "请用 sudo 运行"; exit 1; fi

echo "[1/3] 移除 limits 配置..."
if [[ -f "$LIMITS_DST" ]]; then
  rm -f "$LIMITS_DST"; echo "      已删除 $LIMITS_DST"
else
  echo "      不存在, 跳过"
fi

echo "[2/3] 还原 GRUB..."
LATEST_BAK=$(ls -1t "${GRUB_FILE}".bak.* 2>/dev/null | head -1 || true)
if [[ -n "${LATEST_BAK:-}" ]]; then
  cp -a "$LATEST_BAK" "$GRUB_FILE"
  echo "      已从 $LATEST_BAK 还原"
  update-grub
else
  echo "      没有备份, 手动编辑 $GRUB_FILE 删掉 isolcpus/nohz_full/rcu_nocbs 后 update-grub"
fi

echo "[3/3] 处理 realtime 组..."
if [[ -n "$TARGET_USER" ]] && id -nG "$TARGET_USER" 2>/dev/null | grep -qw realtime; then
  gpasswd -d "$TARGET_USER" realtime >/dev/null 2>&1 || true
  echo "      已把 $TARGET_USER 移出 realtime 组"
fi
echo "      组本身保留 (删了也无害: groupdel realtime)"

echo
echo "回滚完成。注销重登后生效。"
