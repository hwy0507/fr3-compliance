#!/usr/bin/env bash
# ============================================================
# Franka FCI 实时环境准备脚本 (Ubuntu 22.04)
# 作用:
#   1. 创建 realtime 组并把用户加入
#   2. 安装 limits 配置 (rtprio / memlock)
#   3. 给 GRUB 加 CPU 隔离参数 (isolcpus / nohz_full / rcu_nocbs)
#   4. 安装编译与测试依赖 (rt-tests 等)
# 不作用:
#   - 不编译/安装 RT 内核 (Ubuntu 22.04 源里没有, 用 build-rt-kernel.sh)
# 用法:
#   sudo bash /tmp/rt-setup/apply.sh            # 默认对 $SUDO_USER 生效
#   sudo bash /tmp/rt-setup/apply.sh andy       # 指定用户
# 回滚:
#   sudo bash /tmp/rt-setup/rollback.sh
# ============================================================
set -euo pipefail

TARGET_USER="${1:-${SUDO_USER:-}}"
ISOLATE_CPUS="14,15"          # i7-14650HX: CPU 0-15=P核, 16-23=E核; 隔离一对P核
STAMP="$(date +%Y%m%d-%H%M%S)"
GRUB_FILE=/etc/default/grub
LIMITS_DST=/etc/security/limits.d/99-realtime.conf
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ $EUID -ne 0 ]]; then
  echo "请用 sudo 运行: sudo bash $0"; exit 1
fi
if [[ -z "$TARGET_USER" ]]; then
  echo "无法确定目标用户, 请显式指定: sudo bash $0 <用户名>"; exit 1
fi
if ! id "$TARGET_USER" &>/dev/null; then
  echo "用户不存在: $TARGET_USER"; exit 1
fi

echo "=========================================="
echo " 目标用户 : $TARGET_USER"
echo " 隔离 CPU : $ISOLATE_CPUS"
echo "=========================================="

# ---------- 1. realtime 组 ----------
echo "[1/4] 创建 realtime 组并加入用户..."
groupadd -f realtime
if id -nG "$TARGET_USER" | grep -qw realtime; then
  echo "      已是 realtime 组成员, 跳过"
else
  usermod -aG realtime "$TARGET_USER"
  echo "      已把 $TARGET_USER 加入 realtime 组 (需注销重登生效)"
fi

# ---------- 2. limits ----------
echo "[2/4] 安装 limits 配置..."
if [[ -f "$LIMITS_DST" ]] && ! cmp -s "$HERE/99-realtime.conf" "$LIMITS_DST"; then
  cp -a "$LIMITS_DST" "${LIMITS_DST}.bak.${STAMP}"
  echo "      已备份原文件 -> ${LIMITS_DST}.bak.${STAMP}"
fi
install -m 0644 "$HERE/99-realtime.conf" "$LIMITS_DST"
echo "      已写入 $LIMITS_DST"

# ---------- 3. GRUB CPU 隔离 ----------
echo "[3/4] 配置 GRUB CPU 隔离..."
if grep -q 'isolcpus=' "$GRUB_FILE"; then
  echo "      $GRUB_FILE 里已有 isolcpus, 跳过 (如需修改请手动编辑)"
else
  cp -a "$GRUB_FILE" "${GRUB_FILE}.bak.${STAMP}"
  echo "      已备份 -> ${GRUB_FILE}.bak.${STAMP}"
  # 在 GRUB_CMDLINE_LINUX_DEFAULT 的引号内追加参数
  sed -i -E "s/^GRUB_CMDLINE_LINUX_DEFAULT=\"(.*)\"/GRUB_CMDLINE_LINUX_DEFAULT=\"\1 isolcpus=${ISOLATE_CPUS} nohz_full=${ISOLATE_CPUS} rcu_nocbs=${ISOLATE_CPUS}\"/" "$GRUB_FILE"
  # 让启动菜单多停几秒, 方便选 rt 内核
  sed -i -E 's/^GRUB_TIMEOUT=.*/GRUB_TIMEOUT=5/' "$GRUB_FILE"
  echo "      已追加: isolcpus=${ISOLATE_CPUS} nohz_full=${ISOLATE_CPUS} rcu_nocbs=${ISOLATE_CPUS}"
  echo "      当前行: $(grep '^GRUB_CMDLINE_LINUX_DEFAULT=' "$GRUB_FILE")"
  update-grub
  echo "      grub 已更新"
fi

# ---------- 4. 依赖与测试工具 ----------
echo "[4/4] 安装工具链与测试工具..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y rt-tests build-essential bc bison flex libssl-dev libelf-dev \
                   libncurses-dev dwarves rsync kmod cpio zstd xz-utils git
echo "      完成"

echo
echo "=========================================="
echo " 完成。接下来:"
echo "=========================================="
echo " 1) 注销重新登录 (让 realtime 组生效)"
echo " 2) 验证权限:  ulimit -r   # 应显示 99"
echo " 3) 编译 RT 内核: sudo bash $HERE/build-rt-kernel.sh"
echo " 4) 重启, 在 GRUB 里选 '-rt' 内核"
echo " 5) 验证: bash $HERE/verify.sh"
echo
echo " 注意: RT 内核下 NVIDIA 闭源驱动不可用。"
echo "       你已计划把推理放到服务器, 这条不受影响。"
echo "=========================================="
