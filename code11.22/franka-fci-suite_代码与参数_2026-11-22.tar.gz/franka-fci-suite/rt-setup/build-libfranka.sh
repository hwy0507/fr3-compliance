#!/usr/bin/env bash
# ============================================================
# libfranka 0.21.3 完整构建 (Ubuntu 22.04)
# ------------------------------------------------------------
# libfranka >= 0.18 起强依赖 pinocchio（机器人运动学库），
# 而 jammy 源里没有，只能源码编译。
#
# 依赖处理策略（与官方 README 的差异）：
#   官方用静态库 + 自编 Boost 1.77；这里改用 apt 的系统 Boost 1.74
#   + 共享库，省掉 30 分钟的 Boost 编译，功能等价。
#
# 用法: sudo bash ~/rt-setup/build-libfranka.sh
# 日志: /tmp/build-libfranka.log
# 预计: 10~20 分钟
# ============================================================
set -euo pipefail

PIN_TAG="v3.4.0"
LF_TAG="0.21.3"
LOG=/tmp/build-libfranka.log

exec > >(tee -a "$LOG") 2>&1
echo "===== 开始: $(date) ====="

if [[ $EUID -ne 0 ]]; then echo "请用 sudo 运行"; exit 1; fi
# sudo 下 HOME 变成 /root, 必须先从 /etc/passwd 取真实用户的家目录
REAL_USER="${SUDO_USER:-andy}"
REAL_HOME=$(getent passwd "$REAL_USER" | cut -d: -f6)
BUILD_ROOT="${BUILD_ROOT:-$REAL_HOME/lf-build}"
LF_DIR="${LF_DIR:-$REAL_HOME/libfranka}"
echo "      真实用户: $REAL_USER ($REAL_HOME)"
echo "      libfranka: $LF_DIR"

# ---------- 1. 系统依赖 ----------
echo "[1/3] 安装系统依赖..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y \
  build-essential cmake git pkg-config \
  libeigen3-dev libpoco-dev \
  libboost-all-dev liburdfdom-dev liburdfdom-headers-dev \
  libassimp-dev libconsole-bridge-dev libtinyxml2-dev
echo "      完成"

# ---------- 2. pinocchio ----------
echo "[2/3] 编译 pinocchio ${PIN_TAG}..."
mkdir -p "$BUILD_ROOT"
cd "$BUILD_ROOT"
if [[ -f /usr/local/lib/cmake/pinocchio/pinocchioConfig.cmake ]] || \
   [[ -f /usr/local/share/pinocchio/cmake/pinocchioConfig.cmake ]]; then
  echo "      已安装过 pinocchio, 跳过"
else
  if [[ ! -d pinocchio ]]; then
    git clone --depth 1 --branch "$PIN_TAG" --recurse-submodules \
        --shallow-submodules https://github.com/stack-of-tasks/pinocchio.git
  fi
  rm -rf pinocchio/build
  cmake -S pinocchio -B pinocchio/build \
    -DCMAKE_BUILD_TYPE=Release \
    -DBUILD_PYTHON_INTERFACE=OFF \
    -DBUILD_TESTING=OFF \
    -DBUILD_DOCUMENTATION=OFF \
    -DBUILD_WITH_COLLISION_SUPPORT=OFF \
    -DCMAKE_INSTALL_PREFIX=/usr/local
  cmake --build pinocchio/build -j"$(nproc)"
  cmake --install pinocchio/build
  ldconfig
  echo "      pinocchio 安装完成"
fi

# ---------- 3. libfranka ----------
echo "[3/3] 编译 libfranka ${LF_TAG}..."
if [[ ! -d "$LF_DIR/.git" ]]; then
  sudo -u "$REAL_USER" git clone --recurse-submodules \
      https://github.com/frankaemika/libfranka "$LF_DIR"
fi
cd "$LF_DIR"
sudo -u "$REAL_USER" git fetch --tags --quiet || true
sudo -u "$REAL_USER" git checkout "$LF_TAG"
sudo -u "$REAL_USER" git submodule update --init --recursive

rm -rf "$LF_DIR/build"
cmake -S "$LF_DIR" -B "$LF_DIR/build" \
  -DCMAKE_BUILD_TYPE=Release \
  -DBUILD_TESTS=OFF
cmake --build "$LF_DIR/build" -j"$(nproc)"
cmake --install "$LF_DIR/build"
ldconfig

echo
echo "===== 完成: $(date) ====="
echo "可执行文件: $LF_DIR/build/examples/communication_test"
ls -l "$LF_DIR/build/examples/" 2>/dev/null | head
