# Franka FCI 实时环境准备包

针对这台机器: Ubuntu 22.04.5 / i7-14650HX (16核24线程: CPU 0-15 = P核, 16-23 = E核)
目标: 让 libfranka 的 1kHz 控制循环稳定运行 (Max 抖动 < 100 us)

## 文件说明

| 文件 | 作用 |
|---|---|
| `99-realtime.conf` | limits 配置 (rtprio 99 + memlock unlimited) |
| `apply.sh` | 一键: 建组 / 加用户 / 装 limits / 配 GRUB 隔离 / 装工具 |
| `build-rt-kernel.sh` | 下载 6.8.x-rt 源码并编译成 deb (约 30~60 分钟) |
| `verify.sh` | 逐项检查实时条件 + cyclictest 实测 |
| `rollback.sh` | 撤销 limits 与 GRUB 修改 (不动内核) |

## 执行顺序

```bash
# 1. 准备 (会改 /etc, 需要密码)
sudo bash /tmp/rt-setup/apply.sh

# 2. 注销重新登录, 让 realtime 组生效
#    验证: ulimit -r   -> 99

# 3. 编译 RT 内核 (插电, 30~60 分钟)
sudo bash /tmp/rt-setup/build-rt-kernel.sh

# 4. 安装编出来的 deb
sudo dpkg -i /tmp/rt-setup/rt-debs/linux-image-*-rt_*.deb

# 5. 重启, GRUB 菜单选带 "-rt" 的内核

# 6. 验证
bash /tmp/rt-setup/verify.sh
```

## 关键预期

- `apply.sh` 后: `ulimit -r` = 0 -> 99 (须注销重登)
- 装 RT 内核后: `/sys/kernel/realtime` 存在, libfranka 不再报实时错误
- `verify.sh` 末端的 cyclictest: Max 目标 < 100 us

## 已知坑

1. **RT 内核下 NVIDIA 闭源驱动不可用** —— 已决定推理放服务器, 不受影响。
   但意味着这台笔记本的独显在 RT 内核下是废的 (会退回 nouveau)。
2. **Ubuntu 22.04 源里没有 PREEMPT_RT 包** —— `linux-image-lowlatency` 只是
   PREEMPT, **过不了 libfranka 的 `/sys/kernel/realtime` 检查**, 不要用它糊弄。
3. **Realtek RTL8111 网卡** 实时性一般。若 cyclictest 达标但 FCI 仍抖,
   考虑加一块 Intel I210/I350 网卡专供机械臂 (FAQ 1.1)。
4. **编译内核磁盘占用** ~20GB。根分区现在剩 79G, 够用但别同时干别的。
5. GRUB 参数改的是默认启动项; 若你双系统里 Windows 启动项顺序受影响,
   用 `rollback.sh` 或手动编辑 `/etc/default/grub`。

## 出问题怎么办

- 内核编译失败: 文件里有 `CONFIG_MODULE_SIG_*` 报错就是签名项没关干净,
  参考 FAQ 2.1, 改 `.config` 后重跑 `make -j$(nproc) bindeb-pkg`。
- 新核进不去系统: GRUB 里选原来的 `6.8.0-149-generic` 启动, 然后排查。
- 想彻底还原: `sudo bash /tmp/rt-setup/rollback.sh` + 卸载 rt 内核。
