#!/usr/bin/env bash
# ============================================================
# 机械臂直连网卡的实时性调优 (Realtek r8169 / Intel 通用)
# 用法: sudo bash ~/rt-setup/tune-nic.sh [网卡名] [机械臂IP]
# 例:   sudo bash ~/rt-setup/tune-nic.sh enp12s0 172.16.0.2
# 说明: 纯运行时生效(重启失效)，不改任何持久配置。
# ============================================================
set -uo pipefail

IFACE="${1:-enp12s0}"
ROBOT_IP="${2:-172.16.0.2}"

if [[ $EUID -ne 0 ]]; then echo "请用 sudo 运行"; exit 1; fi
if ! ip link show "$IFACE" &>/dev/null; then echo "网卡不存在: $IFACE"; exit 1; fi

echo "=== 目标网卡: $IFACE  机器人: $ROBOT_IP ==="
echo "驱动: $(ethtool -i "$IFACE" 2>/dev/null | awk '/^driver/{print $2}')"

echo "[1/5] 关闭 offload（减少批处理导致的延迟）..."
for off in gro gso tso lro; do
  ethtool -K "$IFACE" "$off" off 2>/dev/null && echo "      $off off" || true
done

echo "[2/5] 加大 ring buffer..."
ethtool -G "$IFACE" rx 1024 tx 1024 2>/dev/null && echo "      rx/tx = 1024" || echo "      不支持，跳过"

echo "[3/5] 关闭中断合并..."
ethtool -C "$IFACE" rx-usecs 0 tx-usecs 0 2>/dev/null && echo "      已设置" || echo "      不支持，跳过"

echo "[4/5] 调整网络栈参数（实时直连场景）..."
sysctl -w net.core.netdev_max_backlog=30000 >/dev/null
sysctl -w net.core.rmem_max=8388608 >/dev/null
sysctl -w net.core.wmem_max=8388608 >/dev/null
sysctl -w net.ipv4.tcp_low_latency=1 >/dev/null 2>&1 || true
echo "      netdev_max_backlog=30000, rmem/wmem=8MB"

echo "[5/5] 测量延迟（500 包，2ms 间隔）..."
sleep 1
ping -c 500 -i 0.002 -W 1 "$ROBOT_IP" 2>&1 | tail -2

echo
echo "判读标准:"
echo "  max  < 1.0 ms  → 可以稳定跑 1kHz FCI"
echo "  max  1~3 ms    → 会偶发 command 超时，靠重试"
echo "  max  > 3 ms    → 建议换 Intel I210/I350 网卡"
