#!/usr/bin/env bash
# ============================================================
# 实时环境验证: 检查 FCI 1kHz 所需条件是否齐备
# 用法: bash /tmp/rt-setup/verify.sh
# ============================================================
set -uo pipefail
PASS=0; FAIL=0
ok()   { echo "  [OK]   $*"; PASS=$((PASS+1)); }
bad()  { echo "  [FAIL] $*"; FAIL=$((FAIL+1)); }
warn() { echo "  [WARN] $*"; }

echo "======== 1. 内核 ========"
echo "  运行中: $(uname -r)"
if [[ -f /sys/kernel/realtime ]]; then
  ok "PREEMPT_RT 已启用 (/sys/kernel/realtime 存在)"
else
  bad "非 PREEMPT_RT 内核 -> libfranka 会报 'does not have realtime capabilities'"
fi
if ls /boot/vmlinuz-*rt* >/dev/null 2>&1; then
  ok "已安装 RT 内核: $(ls /boot/vmlinuz-*rt* | xargs -n1 basename | tr '\n' ' ')"
else
  warn "未安装 RT 内核 (还没编译, 或编译了没装)"
fi

echo "======== 2. 实时权限 ========"
RTP=$(ulimit -r); MEM=$(ulimit -l)
echo "  ulimit -r = $RTP   ulimit -l = $MEM"
if [[ "$RTP" != "0" ]]; then ok "可申请实时优先级"; else
  bad "rtprio=0 -> 需要加入 realtime 组并注销重登"
fi
if [[ "$MEM" == "unlimited" ]]; then ok "可锁定内存 (mlockall)"; else
  warn "memlock = $MEM, 建议 unlimited"
fi
id -nG "$USER" | grep -qw realtime && ok "用户 $USER 在 realtime 组" || bad "用户 $USER 不在 realtime 组"

echo "======== 3. CPU 隔离 ========"
echo "  cmdline: $(cat /proc/cmdline)"
if grep -q 'isolcpus=' /proc/cmdline; then ok "已隔离 CPU"; else
  warn "未隔离 CPU (隔离后实时线程不会被调度器搬走)"
fi

echo "======== 4. 架构 ========"
systemd-detect-virt >/dev/null 2>&1 && bad "检测到虚拟化 -> FCI 不支持" || ok "物理机 (非虚拟化)"

echo "======== 5. 1kHz 抖动实测 ========"
if command -v cyclictest >/dev/null; then
  echo "  跑 10 秒 cyclictest (需要 root)..."
  sudo cyclictest -t -p 80 -n -i 1000 -l 10000 -q 2>/dev/null | tail -3
  echo "  判读: Max 应 < 100 us (合格), > 200 us 需继续优化"
else
  warn "未安装 rt-tests (apply.sh 会装)"
fi

echo
echo "======== 汇总: $PASS 项通过, $FAIL 项失败 ========"
[[ $FAIL -eq 0 ]] && echo "全部通过, 可以跑 libfranka 的 communication_test 了。" \
                  || echo "有失败项, 按上面提示逐条解决。"
