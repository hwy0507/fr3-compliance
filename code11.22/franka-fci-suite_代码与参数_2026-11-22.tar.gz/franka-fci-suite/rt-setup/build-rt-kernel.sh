#!/usr/bin/env bash
# ============================================================
# 编译并打包 PREEMPT_RT 内核 (Ubuntu 22.04 / 6.8 系列)
# ------------------------------------------------------------
# 说明:
#   - Ubuntu 22.04 官方源没有 PREEMPT_RT 内核包, 只能自己编
#   - 本脚本自动找 kernel.org 上最新的 6.8.x-rt 补丁
#   - 沿用当前系统的 .config, 只按 Franka FAQ 2.1 修掉签名相关的项
# 代价:
#   - 约 30~60 分钟 (i7-14650HX 全核编译)
#   - 约 15~20 GB 磁盘, 请确认 / 分区空间足够
#   - 笔记本会很热, 建议插电 + 垫高
# 用法:
#   sudo bash /tmp/rt-setup/build-rt-kernel.sh
# 产物:
#   linux-image-*.deb / linux-headers-*.deb 在脚本所在目录
# ============================================================
set -euo pipefail

BASE_SERIES="6.8"
WORKDIR="${RT_WORKDIR:-/usr/src}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
IDX="https://cdn.kernel.org/pub/linux/kernel/projects/rt/${BASE_SERIES}/"

if [[ $EUID -ne 0 ]]; then echo "请用 sudo 运行"; exit 1; fi

# ---------- 磁盘检查 ----------
AVAIL_GB=$(df -BG --output=avail / | tail -1 | tr -dc '0-9')
echo "根分区可用: ${AVAIL_GB} GB"
if (( AVAIL_GB < 20 )); then
  echo "空间不足 20GB, 编译大概率失败。请先清理或换目录。"; exit 1
fi

# ---------- 构建依赖自检 (bindeb-pkg 需要 debhelper-compat, Ubuntu 上最容易漏) ----------
echo "[0/6] 检查构建依赖..."
MISSING=""
for p in build-essential bc bison flex libssl-dev libelf-dev libncurses-dev \
         rsync kmod cpio zstd xz-utils dpkg-dev fakeroot debhelper; do
  dpkg -s "$p" >/dev/null 2>&1 || MISSING="$MISSING $p"
done
if [[ -n "$MISSING" ]]; then
  echo "      缺失:$MISSING"
  echo "      正在安装..."
  apt-get update -qq
  # shellcheck disable=SC2086
  DEBIAN_FRONTEND=noninteractive apt-get install -y $MISSING
else
  echo "      依赖齐备"
fi

# ---------- 找最新 RT 补丁 ----------
echo "[1/6] 查询 kernel.org 上的 ${BASE_SERIES}.x-rt 补丁..."
# curl 可能未安装, 自动回退到 wget
fetch() { if command -v curl >/dev/null 2>&1; then curl -fsSL "$1"; else wget -qO- "$1"; fi; }
PATCH_FILE=$(fetch "$IDX" | grep -oE "patch-${BASE_SERIES}\.[0-9]+-rt[0-9]+\.patch\.xz" | sort -V | tail -1)
if [[ -z "${PATCH_FILE:-}" ]]; then echo "未找到补丁, 请检查网络或手动指定"; exit 1; fi
KVER=$(echo "$PATCH_FILE" | sed -E "s/^patch-([0-9.]+)-rt[0-9]+\.patch\.xz$/\1/")
RT_N=$(echo "$PATCH_FILE" | sed -E "s/.*-rt([0-9]+)\.patch\.xz$/\1/")
echo "      内核: linux-${KVER}   RT 补丁: rt${RT_N}"

# ---------- 下载 ----------
cd "$WORKDIR"
echo "[2/6] 下载内核源码与补丁..."
[[ -f "linux-${KVER}.tar.xz" ]] || wget -c "https://cdn.kernel.org/pub/linux/kernel/v6.x/linux-${KVER}.tar.xz"
[[ -f "$PATCH_FILE" ]]           || wget -c "${IDX}${PATCH_FILE}"

# ---------- 解压 + 打补丁 ----------
SRC="linux-${KVER}"
if [[ ! -d "$SRC" ]]; then
  echo "[3/6] 解压..."
  tar -xf "linux-${KVER}.tar.xz"
fi
cd "$SRC"
if [[ ! -f .patched ]]; then
  echo "      应用 RT 补丁..."
  xzcat "../${PATCH_FILE}" | patch -p1 --forward
  touch .patched
fi

# ---------- 配置 ----------
echo "[4/6] 生成配置 (基于当前系统 .config)..."
cp -f "/boot/config-$(uname -r)" .config
make olddefconfig

echo "      按 Franka FAQ 2.1 处理签名/调试项..."
scripts/config --disable MODULE_SIG_ALL
scripts/config --set-str MODULE_SIG_KEY ""
scripts/config --set-str SYSTEM_TRUSTED_KEYS ""
scripts/config --set-str SYSTEM_REVOCATION_KEYS ""
scripts/config --disable DEBUG_INFO
scripts/config --disable DEBUG_INFO_DWARF5
scripts/config --enable PREEMPT_RT
make olddefconfig

if ! grep -q '^CONFIG_PREEMPT_RT=y' .config; then
  echo "!! 警告: CONFIG_PREEMPT_RT 未启用, 请手动执行 make menuconfig"
  echo "   路径: General setup -> Preemption Model -> Fully Preemptible Kernel (RT)"
  exit 1
fi
echo "      CONFIG_PREEMPT_RT=y 已确认"

# ---------- 编译 ----------
echo "[5/6] 开始编译 (约 30~60 分钟, 可以去干别的)..."
make -j"$(nproc)" bindeb-pkg LOCALVERSION=-rt

# ---------- 收集产物 ----------
echo "[6/6] 收集 deb 包..."
cd "$WORKDIR"
mkdir -p "$HERE/rt-debs"
mv -f linux-image-*-rt_*.deb linux-headers-*-rt_*.deb linux-libc-dev-*-rt_*.deb "$HERE/rt-debs/" 2>/dev/null || true
ls -lh "$HERE/rt-debs/" 2>/dev/null || echo "未找到 deb 产物, 请检查编译日志"

echo
echo "=========================================="
echo " 编译完成。安装:"
echo "   sudo dpkg -i $HERE/rt-debs/linux-image-*-rt_*.deb"
echo "   sudo dpkg -i $HERE/rt-debs/linux-headers-*-rt_*.deb 2>/dev/null || true"
echo " 然后重启, GRUB 菜单里选带 '-rt' 的内核。"
echo "=========================================="
