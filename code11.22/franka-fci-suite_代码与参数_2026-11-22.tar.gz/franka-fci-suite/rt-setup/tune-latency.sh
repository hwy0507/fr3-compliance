#!/usr/bin/env bash
# ============================================================
# FCI 低延迟调优
#   --runtime  立即生效(重启失效): 性能 governor + 关深睡
#   --persist  写入 GRUB, 重启后永久生效
#   --status   查看当前状态
# 用法: sudo bash ~/rt-setup/tune-latency.sh --runtime
# ============================================================
set -euo pipefail

MODE="${1:---status}"

if [[ $EUID -ne 0 ]] && [[ "$MODE" != "--status" ]]; then
  echo "请用 sudo 运行: sudo bash $0 $MODE"; exit 1
fi

status() {
  echo "=== CPU 频率调节器 ==="
  for c in /sys/devices/system/cpu/cpu{0,14,16}/cpufreq/scaling_governor; do
    [[ -f "$c" ]] && echo "  $(echo "$c" | grep -o 'cpu[0-9]*'): $(cat "$c")"
  done
  echo "=== C-state 开关 (1=已禁用) ==="
  for d in /sys/devices/system/cpu/cpu14/cpuidle/state*; do
    printf "  %-10s latency=%-6s disabled=%s\n" "$(cat $d/name)" "$(cat $d/latency)" "$(cat $d/disable 2>/dev/null || echo 0)"
  done
  echo "=== 启动参数 ==="
  grep -oE "(isolcpus|nohz_full|rcu_nocbs|irqaffinity|intel_idle.max_cstate|processor.max_cstate|nowatchdog)=[^ ]*" /proc/cmdline | sed 's/^/  /' || echo "  (无)"
  echo "=== 电源守护进程 ==="
  systemctl is-active thermald power-profiles-daemon 2>/dev/null | paste -sd' ' | sed 's/^/  /'
}

apply_runtime() {
  echo "[1/3] 切到 performance governor..."
  local n=0
  for c in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    echo performance > "$c" 2>/dev/null && n=$((n+1))
  done
  echo "      已设置 $n 个 CPU"

  echo "[2/3] 禁用 C1 以上的深睡眠 (C2/C3 退出延迟 127/1048 us)..."
  for d in /sys/devices/system/cpu/cpu*/cpuidle/state*; do
    local name; name=$(cat "$d/name" 2>/dev/null || echo "")
    case "$name" in
      POLL|C1*|"") continue ;;
    esac
    echo 1 > "$d/disable" 2>/dev/null || true
  done
  echo "      完成 (只保留 POLL/C1)"

  echo "[3/3] 电源配置切到 performance..."
  if command -v powerprofilesctl >/dev/null 2>&1; then
    powerprofilesctl set performance 2>/dev/null && echo "      power-profiles-daemon -> performance" \
      || echo "      切换失败(忽略)"
  fi

  echo
  echo "运行时调优完成。现在可以测:"
  echo "  taskset -c 14 cyclictest -t 1 -p 80 -i 1000 -l 10000"
  echo "注意: 这是临时生效, 重启后失效。确认有效后用 --persist 固化。"
}

apply_persist() {
  local GRUB_FILE=/etc/default/grub
  local EXTRA="irqaffinity=0-13,16-23 intel_idle.max_cstate=1 processor.max_cstate=1 nowatchdog nmi_watchdog=0"
  if grep -q 'intel_idle.max_cstate' "$GRUB_FILE"; then
    echo "GRUB 里已有调优参数, 跳过"
    grep '^GRUB_CMDLINE_LINUX_DEFAULT' "$GRUB_FILE"
    return
  fi
  cp -a "$GRUB_FILE" "${GRUB_FILE}.bak.$(date +%Y%m%d-%H%M%S)"
  sed -i -E "s/^GRUB_CMDLINE_LINUX_DEFAULT=\"(.*)\"/GRUB_CMDLINE_LINUX_DEFAULT=\"\1 ${EXTRA}\"/" "$GRUB_FILE"
  echo "已追加: $EXTRA"
  grep '^GRUB_CMDLINE_LINUX_DEFAULT' "$GRUB_FILE"
  update-grub
  echo "重启后生效。"
}

case "$MODE" in
  --runtime) apply_runtime ;;
  --persist) apply_persist ;;
  --status)  status ;;
  *) echo "用法: $0 [--runtime|--persist|--status]"; exit 1 ;;
esac
